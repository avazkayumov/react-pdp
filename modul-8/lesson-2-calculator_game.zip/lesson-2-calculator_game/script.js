let appendMinutes = document.querySelector(".minutes")
let appendSeconds = document.querySelector(".seconds")

let firstNumber = document.querySelector(".firstnumber")
let operator = document.querySelector(".operator")
let secondNumber = document.querySelector(".secondnumber")
let leftAnswer = document.querySelector(".leftanswer")
let centerAnswer = document.querySelector(".centeranswer")
let rightAnswer = document.querySelector(".rightanswer")
let container = document.querySelector(".question-container")

let minutes = 0;
let seconds = 5;
let interval;


let ans1 = Math.floor(Math.random() * 11);
let ans2 = Math.floor(Math.random() * 11);
let ans3 = ques1 + ques2;

function render() {
    let ques1 = Math.floor(Math.random() * 11);
    let ques2 = Math.floor(Math.random() * 11);
    
    // firstNumber.innerHTML = ques1
    // secondNumber.innerHTML = ques2
    
    leftAnswer.innerHTML = ans1
    centerAnswer.innerHTML = ans2
    rightAnswer.innerHTML = ans3

    container.insertAdjacentHTML("afterbegin", `
        <div class="firstnumber">${ques1}</div>
        <div class="operator">+</div>
        <div class="secondnumber">${ques2}</div>
    `)

    function findAnswer(event) {
        let clickedNum = event.target.innerHTML 
        console.log(clickedNum)
        if (clickedNum == ques1 + ques2) {
            seconds = seconds + 5
            render()
    
        }else {
            console.log(false)
        }
    }
}

function start() {
    interval = setInterval(startTimer, 1000)
}

function startTimer() {
    seconds --

    if(seconds == 0) {
        clearInterval(interval)
    }   

    appendMinutes.innerHTML = String(minutes).padStart(2, 0)
    appendSeconds.innerHTML = String(seconds).padStart(2, 0)
}

render()